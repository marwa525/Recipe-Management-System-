/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package recipemanagementsystemapplication;

/**
 *
 * @author cui
 */
// Abstract Factory Pattern
interface RecipeAbstractFactory {
    Recipe createStarter();
    Recipe createMainCourse();
}
