/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recipemanagementsystemapplication;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author cui
 */
// Builder Pattern
class RecipeBuilder {
    private String name;
    private List<String> ingredients = new ArrayList<>();
    private List<String> instructions = new ArrayList<>();

    public RecipeBuilder setName(String name) {
        this.name = name;
        return this;
    }

    public RecipeBuilder addIngredient(String ingredient) {
        ingredients.add(ingredient);
        return this;
    }

    public RecipeBuilder addInstruction(String instruction) {
        instructions.add(instruction);
        return this;
    }

    public ComplexRecipe build() {
        return new ComplexRecipe(name, ingredients, instructions);
    }
}

class ComplexRecipe extends Recipe {
    private List<String> ingredients;
    private List<String> instructions;

    public ComplexRecipe(String name, List<String> ingredients, List<String> instructions) {
        super(name);
        this.ingredients = ingredients;
        this.instructions = instructions;
    }

    @Override
    public void prepare() {
        System.out.println("Preparing complex recipe: " + name);
        System.out.println("Ingredients: " + String.join(", ", ingredients));
        System.out.println("Instructions: " + String.join(" | ", instructions));
    }
}

