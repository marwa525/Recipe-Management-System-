/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recipemanagementsystemapplication;

/**
 *
 * @author cui
 */
abstract class Recipe {
    protected String name;

    public Recipe(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public abstract void prepare();
}

class VegetarianRecipe extends Recipe {
    public VegetarianRecipe(String name) {
        super(name);
    }

    @Override
    public void prepare() {
        System.out.println("Preparing vegetarian recipe: " + name);
    }
}

class NonVegetarianRecipe extends Recipe {
    public NonVegetarianRecipe(String name) {
        super(name);
    }

    @Override
    public void prepare() {
        System.out.println("Preparing non-vegetarian recipe: " + name);
    }
}

class RecipeFactory {
    public static Recipe createRecipe(String type, String name) {
        switch (type.toLowerCase()) {
            case "vegetarian":
                return new VegetarianRecipe(name);
            case "non_vegetarian":
                return new NonVegetarianRecipe(name);
            default:
                throw new IllegalArgumentException("Unknown recipe type");
        }
    }
}


