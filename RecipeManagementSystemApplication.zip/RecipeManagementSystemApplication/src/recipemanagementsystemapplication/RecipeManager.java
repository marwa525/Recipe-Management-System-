/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recipemanagementsystemapplication;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author cui
 */
// Singleton Pattern
class RecipeManager {
    private static RecipeManager instance;
    private List<Recipe> recipes;

    private RecipeManager() {
        recipes = new ArrayList<>();
    }

    public static RecipeManager getInstance() {
        if (instance == null) {
            instance = new RecipeManager();
        }
        return instance;
    }

    public void addRecipe(Recipe recipe) {
        recipes.add(recipe);
    }

    public void removeRecipe(Recipe recipe) {
        recipes.remove(recipe);
    }

    public Recipe findRecipe(String name) {
        for (Recipe recipe : recipes) {
            if (recipe.getName().equalsIgnoreCase(name)) {
                return recipe;
            }
        }
        return null;
    }

    public List<Recipe> getAllRecipes() {
        return new ArrayList<>(recipes);
    }
}

