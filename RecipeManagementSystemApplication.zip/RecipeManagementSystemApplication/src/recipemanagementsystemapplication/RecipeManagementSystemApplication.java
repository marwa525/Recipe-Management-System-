/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package recipemanagementsystemapplication;

import java.util.List;

/**
 *
 * @author cui
 */
public class RecipeManagementSystemApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       // Factory Method pattern
        Recipe vegRecipe = RecipeFactory.createRecipe("vegetarian", "Paneer Tikka");
        Recipe nonVegRecipe = RecipeFactory.createRecipe("non_vegetarian", "Chicken Biryani");

        vegRecipe.prepare();
        nonVegRecipe.prepare();

        // Abstract Factory pattern
        RecipeAbstractFactory vegFactory = new VegetarianRecipeFactory();
        RecipeAbstractFactory nonVegFactory = new NonVegetarianRecipeFactory();

        Recipe vegStarter = vegFactory.createStarter();
        Recipe vegMainCourse = vegFactory.createMainCourse();
        Recipe nonVegStarter = nonVegFactory.createStarter();
        Recipe nonVegMainCourse = nonVegFactory.createMainCourse();

        vegStarter.prepare();
        vegMainCourse.prepare();
        nonVegStarter.prepare();
        nonVegMainCourse.prepare();

        // Builder pattern
        RecipeBuilder builder = new RecipeBuilder();
        ComplexRecipe complexRecipe = builder.setName("Pizza")
                .addIngredient("Dough")
                .addIngredient("Cheese")
                .addInstruction("Prepare dough and add toppings")
                .build();

        complexRecipe.prepare();

        
        // Singleton pattern
        RecipeManager recipeManager = RecipeManager.getInstance();
        recipeManager.addRecipe(vegRecipe);
        recipeManager.addRecipe(nonVegRecipe);

        List<Recipe> allRecipes = recipeManager.getAllRecipes();
        for (Recipe recipe : allRecipes) {
            System.out.println("Recipe: " + recipe.getName());
        }
        // Decorator pattern
        Recipe spicyVegRecipe = new SpicyDecorator(new VegetarianRecipe("Spicy Paneer Tikka"));
        spicyVegRecipe.prepare();

        // Facade pattern
        RecipeFacade facade = new RecipeFacade();
        facade.prepareVegMeal();
        facade.prepareNonVegMeal();

        // Composite pattern
        RecipeGroup group = new RecipeGroup("Full Course Meal");
        group.addRecipe(new VegetarianRecipe("Salad"));
        group.addRecipe(new NonVegetarianRecipe("Grilled Chicken"));
        group.prepare();

        // Iterator pattern
        RecipeCollection collection = new RecipeCollection();
        collection.addRecipe(new VegetarianRecipe("Vegetable Curry"));
        collection.addRecipe(new NonVegetarianRecipe("Fish Curry"));

        for (Recipe recipe : collection) {
            System.out.println("Iterator Recipe: " + recipe.getName());
        }

        // Adapter pattern
        NewRecipeInterface adaptedRecipe = new RecipeAdapter(new NonVegetarianRecipe("Beef Steak"));
        adaptedRecipe.makeRecipe();
    }
    
}
