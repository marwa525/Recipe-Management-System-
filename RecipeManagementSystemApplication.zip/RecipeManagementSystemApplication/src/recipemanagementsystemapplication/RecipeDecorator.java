/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recipemanagementsystemapplication;

/**
 *
 * @author cui
 */
abstract class RecipeDecorator extends Recipe {
    protected Recipe decoratedRecipe;

    public RecipeDecorator(Recipe decoratedRecipe) {
        super(decoratedRecipe.getName());
        this.decoratedRecipe = decoratedRecipe;
    }

    @Override
    public void prepare() {
        decoratedRecipe.prepare();
    }
}

class SpicyDecorator extends RecipeDecorator {
    public SpicyDecorator(Recipe decoratedRecipe) {
        super(decoratedRecipe);
    }

    @Override
    public void prepare() {
        decoratedRecipe.prepare();
        System.out.println("Adding spicy flavor to " + decoratedRecipe.getName());
    }
}
