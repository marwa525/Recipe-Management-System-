/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recipemanagementsystemapplication;

/**
 *
 * @author cui
 */
class RecipeFacade {
    private RecipeAbstractFactory vegFactory;
    private RecipeAbstractFactory nonVegFactory;

    public RecipeFacade() {
        vegFactory = new VegetarianRecipeFactory();
        nonVegFactory = new NonVegetarianRecipeFactory();
    }

    public void prepareVegMeal() {
        Recipe starter = vegFactory.createStarter();
        Recipe mainCourse = vegFactory.createMainCourse();
        starter.prepare();
        mainCourse.prepare();
    }

    public void prepareNonVegMeal() {
        Recipe starter = nonVegFactory.createStarter();
        Recipe mainCourse = nonVegFactory.createMainCourse();
        starter.prepare();
        mainCourse.prepare();
    }
}

