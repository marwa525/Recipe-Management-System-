/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package recipemanagementsystemapplication;

/**
 *
 * @author cui
 */
interface NewRecipeInterface {
    void makeRecipe();
}

class RecipeAdapter implements NewRecipeInterface {
    private Recipe oldRecipe;

    public RecipeAdapter(Recipe oldRecipe) {
        this.oldRecipe = oldRecipe;
    }

    @Override
    public void makeRecipe() {
        oldRecipe.prepare();
    }
}
