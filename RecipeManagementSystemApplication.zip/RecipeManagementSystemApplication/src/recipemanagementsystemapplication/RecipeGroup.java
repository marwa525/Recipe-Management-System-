/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recipemanagementsystemapplication;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author cui
 */
//composite dp
class RecipeGroup extends Recipe {
    private List<Recipe> recipes = new ArrayList<>();

    public RecipeGroup(String name) {
        super(name);
    }

    public void addRecipe(Recipe recipe) {
        recipes.add(recipe);
    }

    public void removeRecipe(Recipe recipe) {
        recipes.remove(recipe);
    }

    @Override
    public void prepare() {
        System.out.println("Preparing recipe group: " + name);
        for (Recipe recipe : recipes) {
            recipe.prepare();
        }
    }
}
