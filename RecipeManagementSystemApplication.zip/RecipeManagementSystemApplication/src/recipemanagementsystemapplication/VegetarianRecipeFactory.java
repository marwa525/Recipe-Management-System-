/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recipemanagementsystemapplication;

/**
 *
 * @author cui
 */
class VegetarianRecipeFactory implements RecipeAbstractFactory {
    @Override
    public Recipe createStarter() {
        return new VegetarianRecipe("Vegetarian Starter");
    }

    @Override
    public Recipe createMainCourse() {
        return new VegetarianRecipe("Vegetarian Main Course");
    }
}
